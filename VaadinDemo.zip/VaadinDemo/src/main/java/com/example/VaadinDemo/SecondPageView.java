package com.example.VaadinDemo;



import com.vaadin.ui.Label;

import com.vaadin.ui.VerticalLayout;

import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener;

public class SecondPageView extends VerticalLayout implements View {

    @Override
    public void enter(ViewChangeListener.ViewChangeEvent event) {
        // Retrieve values from the URL parameters
        String firstName = event.getParameters().split("/")[0];
        String lastName = event.getParameters().split("/")[1];

        // Display the values in the new view
        addComponent(new Label("First Name=" + firstName));
        addComponent(new Label("Last Name=" + lastName));
        addComponent(new Label("Thank you for clicking"));
    }
}