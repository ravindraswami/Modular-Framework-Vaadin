package com.example.VaadinDemo;

/* Project Name: Modular Framework (Vaadin)
 * 
 * Author Name : Mr. Ravindra S.Swami 
 * 
 * Description : Two TextField data get and when submit button click then display the textfield data.
 * 
 * Contact No. : +91-7020360237
 */
import javax.servlet.annotation.WebServlet;

import com.vaadin.annotations.Theme;
import com.vaadin.annotations.VaadinServletConfiguration;
import com.vaadin.server.VaadinRequest;
import com.vaadin.server.VaadinServlet;
import com.vaadin.ui.Button;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.Label;
import com.vaadin.ui.TextField;
import com.vaadin.ui.UI;
import com.vaadin.ui.VerticalLayout;

import com.vaadin.navigator.Navigator;

@Theme("mytheme")
@SuppressWarnings("serial")
public class MyVaadinUI extends UI
{
	 private TextField fname;
	 private Button sayHello;
	 private TextField lname;

    @WebServlet(value = "/*", asyncSupported = true)
    @VaadinServletConfiguration(productionMode = false, ui = MyVaadinUI.class)
    public static class Servlet extends VaadinServlet {
    }

    @Override
    protected void init(VaadinRequest request) {
        final VerticalLayout layout = new VerticalLayout();
        layout.setMargin(true);
        setContent(layout);
        
        fname = new TextField("Your First Name");
        lname = new TextField("Your Second Name");
        
        Button button = new Button("Click Me");
        button.addClickListener(new Button.ClickListener() {
            public void buttonClick(ClickEvent event) {
            	layout.addComponent(new Label("First Name="+fname.getValue()));
            	layout.addComponent(new Label("Last Name="+lname.getValue()));
                layout.addComponent(new Label("Thank you for clicking"));
                getUI().getNavigator().navigateTo("secondPage/" + fname.getValue() + "/" + lname.getValue());
                
            }
        });
        layout.addComponents(fname,lname,button);
        //layout.addComponent();
        //Navigator navigator = new Navigator(this, this);
        //navigator.addView("secondPage", new SecondPageView());
    }
    

}